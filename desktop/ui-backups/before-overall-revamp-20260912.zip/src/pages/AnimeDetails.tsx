import React, { useEffect, useRef, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { fetchAnimeDetails, fetchAnimeEpisodes } from '../api/jikan';
import { Download, Plus, Check, Heart, Star, Calendar, Clock, Tv, Play, ChevronLeft, ChevronRight } from 'lucide-react';
import { useStore } from '../store/useStore';
import { animePath, mangaPath, watchPath } from '../lib/slug';
import Seo from '../components/Seo';
import RelatedBlogArticles from '../components/RelatedBlogArticles';
import { saveRecentAnime } from '../lib/activity';
import { isDesktopApp } from '../lib/desktop';
import { animeIdentity } from '../lib/animeIdentity';

function formatStatus(value?: string) {
  return value ? value.replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, (letter) => letter.toUpperCase()) : 'Unknown';
}

function formatNextAiring(seconds?: number) {
  if (!seconds) return null;
  return new Date(seconds * 1000).toLocaleString([], {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    timeZoneName: 'short',
  });
}

function isNotYetAired(anime: any) {
  const status = String(anime?.status || '').toUpperCase();
  return status === 'NOT_YET_RELEASED' || status === 'NOT_YET_AIRED' || status.includes('NOT_YET');
}

function knownAiredEpisodeCount(anime: any, episodeItems: any[] = []) {
  const pageMax = episodeItems.length
    ? Math.max(...episodeItems.map((episode: any) => Number(episode?.mal_id) || 0))
    : 0;
  if (anime?.nextAiringEpisode?.episode) return Math.max(anime.nextAiringEpisode.episode - 1, pageMax, 0);
  if (String(anime?.status || '').toUpperCase() === 'FINISHED') return Math.max(anime?.episodes || 1, pageMax, 1);
  if (String(anime?.status || '').toUpperCase() === 'RELEASING') {
    return Math.max(anime?.episodes || 0, anime?.streamingEpisodes?.length || 0, pageMax, 1);
  }
  return Math.max(pageMax, anime?.episodes || 0, 0);
}

function canShowDownloadOptions(anime: any, episodeItems: any[] = []) {
  if (!anime || isNotYetAired(anime)) return false;
  return true;
}

export default function AnimeDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { isInMyList, addToMyList, removeFromMyList, isLiked, toggleLike } = useStore();
  const relationsScrollRef = useRef<HTMLDivElement>(null);
  const recommendationsScrollRef = useRef<HTMLDivElement>(null);

  const scroll = (ref: React.RefObject<HTMLDivElement>, direction: 'left' | 'right') => {
    if (ref.current) {
      const scrollAmount = direction === 'left' ? -300 : 300;
      ref.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  const [epPage, setEpPage] = useState(0);

  const { data, isLoading, error } = useQuery({
    queryKey: ['anime', id],
    queryFn: () => fetchAnimeDetails(id!),
    enabled: !!id,
    retry: false
  });

  const { data: episodesData, isLoading: episodesLoading } = useQuery({
    queryKey: ['episodes', id, epPage],
    queryFn: () => fetchAnimeEpisodes(id!, epPage + 1),
    enabled: !!id,
  });

  const anime = data?.data;
  const desktop = isDesktopApp();

  useEffect(() => {
    if (!anime || !id) return;
    const cleanPath = animePath(anime);
    if (/^\d+$/.test(id) && cleanPath !== `/anime/${id}`) {
      navigate(cleanPath, { replace: true });
    }
  }, [anime, id, navigate]);

  useEffect(() => {
    if (anime) saveRecentAnime(anime);
  }, [anime]);

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center">
      <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
    </div>;
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center text-center p-4">
        <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-8 max-w-md">
          <p className="text-red-500 font-bold mb-4">{error.message || 'An error occurred while fetching details.'}</p>
          <Link to="/" className="text-sm font-semibold text-primary hover:underline">Return Home</Link>
        </div>
      </div>
    );
  }

  if (!anime) return <div className="text-center py-20">Anime not found</div>;

  const animeId = animeIdentity(anime);
  const inList = isInMyList(animeId);
  const liked = isLiked(animeId);
  const genres = anime.genres?.map((genre: any) => genre.name).filter(Boolean) || [];
  const studios = anime.studios?.map((studio: any) => studio.name).filter(Boolean) || [];
  const statusLabel = formatStatus(anime.status);
  const nextEpisodeNumber = anime.nextAiringEpisode?.episode;
  const nextAiringTime = formatNextAiring(anime.nextAiringEpisode?.airingAt);
  const detailEpisodes = episodesData?.data || [];
  const downloadOptionsAvailable = canShowDownloadOptions(anime, detailEpisodes);
  const latestAiredEpisode = knownAiredEpisodeCount(anime, detailEpisodes);
  const episodeCountText = anime.episodes ? `${anime.episodes} episodes` : nextEpisodeNumber ? `${Math.max(nextEpisodeNumber - 1, 0)} episodes aired so far` : 'episode count not confirmed';
  const malScoreText = anime.score ? `MAL Score ${anime.score}` : 'MAL Score N/A';
  const malPopularityText = anime.popularity ? `#${anime.popularity.toLocaleString()}` : 'N/A';
  const seoDescription = `${anime.title} anime details with synopsis, genres, ${episodeCountText}, status, related anime, recommendations, and download source search options.`;
  const mainStudio = studios[0];
  const animeImage = anime.images?.jpg?.large_image_url || anime.images?.jpg?.image_url;
  const updatedLabel = new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  const jsonLd = [
    {
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://www.streamnyaa.xyz/' },
        { '@type': 'ListItem', position: 2, name: 'Anime', item: 'https://www.streamnyaa.xyz/anime/popular' },
        { '@type': 'ListItem', position: 3, name: anime.title, item: 'https://www.streamnyaa.xyz' + animePath(anime) },
      ],
    },
    {
      '@context': 'https://schema.org',
      '@type': 'TVSeries',
      name: anime.title,
      alternateName: [anime.title_english, anime.title_romaji].filter(Boolean),
      description: anime.synopsis || seoDescription,
      image: animeImage,
      genre: genres,
      numberOfEpisodes: anime.episodes || undefined,
      aggregateRating: anime.score ? {
        '@type': 'AggregateRating',
        ratingValue: anime.score,
        bestRating: 10,
        worstRating: 0,
      } : undefined,
      productionCompany: mainStudio ? { '@type': 'Organization', name: mainStudio } : undefined,
      url: 'https://www.streamnyaa.xyz' + animePath(anime),
    },
    {
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: [
        {
          '@type': 'Question',
          name: `What is ${anime.title} about?`,
          acceptedAnswer: {
            '@type': 'Answer',
            text: anime.synopsis || `${anime.title} is an anime listed on StreamNyaa with metadata, episode information, related titles, and discovery links.`,
          },
        },
        {
          '@type': 'Question',
          name: `How many episodes does ${anime.title} have?`,
          acceptedAnswer: {
            '@type': 'Answer',
            text: `${anime.title} has ${episodeCountText}. ${nextEpisodeNumber ? `The next listed episode is episode ${nextEpisodeNumber}${nextAiringTime ? `, scheduled around ${nextAiringTime}` : ''}.` : ''}`,
          },
        },
        {
          '@type': 'Question',
          name: `Where can I find ${anime.title} downloads?`,
          acceptedAnswer: {
            '@type': 'Answer',
            text: `The ${anime.title} downloads page on StreamNyaa helps search source metadata, including episode results, batch results, file sizes, seed counts, and sub or dub filters.`,
          },
        },
      ],
    },
  ];

  const handleListToggle = () => {
    if (inList) removeFromMyList(animeId);
    else addToMyList(anime);
  };

  return (
    <div className="pb-20">
      <Seo
        title={`${anime.title} Anime Details, Episodes and Downloads | StreamNyaa`}
        description={seoDescription}
        canonicalPath={animePath(anime)}
        image={animeImage}
        jsonLd={jsonLd}
      />
      {/* Hero Section */}
      <div className="relative h-[50vh] md:h-[60vh] w-full overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent z-10" />
        <div className="absolute inset-0 bg-black/40 z-10" />
        <img
          src={animeImage}
          alt={anime.title}
          className="w-full h-full object-cover blur-sm scale-105"
          referrerPolicy="no-referrer"
        />
      </div>

      <div className="container mx-auto px-4 relative z-20 -mt-32 md:-mt-48 flex flex-col md:flex-row gap-8">
        {/* Poster */}
        <div className="w-48 md:w-64 shrink-0 mx-auto md:mx-0">
          <div className="aspect-[3/4] rounded-xl overflow-hidden shadow-2xl border-4 border-background bg-secondary">
            <img
              src={animeImage}
              alt={anime.title}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0 pt-4 md:pt-16 text-center md:text-left">
          <h1 className="text-3xl md:text-5xl font-black text-foreground mb-2">{anime.title}</h1>
          <h2 className="text-lg text-muted-foreground mb-6">{anime.title}</h2>

          <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 mb-8 text-sm font-medium">
            <div className="flex items-center gap-1 text-yellow-500">
              <Star className="w-4 h-4 fill-current" />
              <span>{malScoreText}</span>
            </div>
            <div className="flex items-center gap-1 text-muted-foreground">
              <Tv className="w-4 h-4" />
              <span>{anime.type}</span>
            </div>
            <div className="flex items-center gap-1 text-muted-foreground">
              <Calendar className="w-4 h-4" />
              <span>{anime.year || 'N/A'}</span>
            </div>
            <div className="flex items-center gap-1 text-muted-foreground">
              <Clock className="w-4 h-4" />
              <span>{anime.episodes ? `${anime.episodes} EPS` : 'N/A'}</span>
            </div>
            <div className="px-2 py-0.5 bg-secondary rounded text-foreground uppercase">
              {anime.status || 'N/A'}
            </div>
            <div className="px-2 py-0.5 bg-secondary/60 rounded text-muted-foreground">
              Updated {updatedLabel}
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 mb-8">
            {downloadOptionsAvailable ? (
              <>
                {desktop ? (
                  <Link
                    to={`${watchPath(anime)}?${new URLSearchParams({ ...(latestAiredEpisode ? { ep: String(latestAiredEpisode) } : {}), type: 'sub' }).toString()}`}
                    className="flex items-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-3 rounded-full font-bold transition-transform hover:scale-105"
                  >
                    <Play className="w-5 h-5 fill-current" />
                    Watch
                  </Link>
                ) : null}
                <Link
                  to={animePath(anime, '/downloads')}
                  className={`${desktop ? 'bg-secondary hover:bg-secondary/80 text-foreground' : 'bg-primary hover:bg-primary/90 text-primary-foreground'} flex items-center gap-2 px-8 py-3 rounded-full font-bold transition-transform hover:scale-105`}
                >
                  <Download className="w-5 h-5" />
                  Downloads
                </Link>
              </>
            ) : (
              <span className="flex items-center gap-2 rounded-full border border-border bg-secondary/70 px-6 py-3 font-bold text-muted-foreground">
                <Calendar className="h-5 w-5" />
                Downloads after airing
              </span>
            )}
            <button
              onClick={handleListToggle}
              className={`flex items-center gap-2 px-6 py-3 rounded-full font-medium transition-all shadow-sm active:scale-95 ${
                inList 
                  ? 'bg-green-500/20 text-green-500 hover:bg-green-500/30' 
                  : 'bg-secondary hover:bg-secondary/80 text-foreground'
              }`}
            >
              {inList ? <Check className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
              {inList ? 'In List' : 'Add to List'}
            </button>
            <button
              onClick={() => toggleLike(anime)}
              className="p-3 bg-secondary hover:bg-secondary/80 text-foreground rounded-full transition-colors"
            >
              <Heart className={`w-5 h-5 ${liked ? 'fill-primary text-primary' : ''}`} />
            </button>
            {anime.trailer?.embed_url && (
              <div className="w-full max-w-[320px] sm:w-[300px] lg:w-[340px]">
                <div className="rounded-2xl border border-[var(--glass-border)] bg-background/70 p-2 shadow-xl shadow-black/20 backdrop-blur">
                  <div className="mb-2 flex items-center justify-between gap-3 px-1">
                    <span className="flex items-center gap-1.5 text-xs font-bold text-foreground">
                      <Play className="h-3.5 w-3.5 fill-primary text-primary" />
                      Trailer
                    </span>
                    <span className="text-xs text-muted-foreground">{anime.year || anime.type || 'Preview'}</span>
                  </div>
                  <div className="aspect-video overflow-hidden rounded-xl border border-white/10 bg-black">
                    <iframe
                      src={anime.trailer.embed_url}
                      className="h-full w-full border-0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                      title={`${anime.title} Trailer`}
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-6">
            {downloadOptionsAvailable ? (
              <section className="rounded-2xl border border-primary/20 bg-primary/5 p-4 md:p-5">
                <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                  <div>
                    <p className="text-[11px] font-black uppercase tracking-wider text-primary">Best download options</p>
                    <h3 className="mt-1 text-xl font-black text-foreground">{anime.title} source search</h3>
                    <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">
                      Search source metadata by latest listed episode, batch results, subtitles, or dual-audio releases without leaving this title page.
                    </p>
                  </div>
                  <div className="grid gap-2 sm:grid-cols-2 lg:min-w-[420px]">
                    <Link to={animePath(anime, latestAiredEpisode ? `/downloads?ep=${latestAiredEpisode}&type=sub` : '/downloads?type=sub')} className="rounded-xl border border-border bg-background/70 px-4 py-3 text-sm font-black text-foreground transition-colors hover:border-primary/45 hover:text-primary">
                      Latest episode
                      <span className="mt-1 block text-xs font-semibold text-muted-foreground">{latestAiredEpisode ? `Episode ${latestAiredEpisode} sub` : 'Episode source search'}</span>
                    </Link>
                    <Link to={animePath(anime, '/downloads?type=sub')} className="rounded-xl border border-border bg-background/70 px-4 py-3 text-sm font-black text-foreground transition-colors hover:border-primary/45 hover:text-primary">
                      Batch download
                      <span className="mt-1 block text-xs font-semibold text-muted-foreground">Full-season source metadata</span>
                    </Link>
                    <Link to={animePath(anime, latestAiredEpisode ? `/downloads?ep=${latestAiredEpisode}&type=sub` : '/downloads?type=sub')} className="rounded-xl border border-border bg-background/70 px-4 py-3 text-sm font-black text-foreground transition-colors hover:border-primary/45 hover:text-primary">
                      Sub quick link
                      <span className="mt-1 block text-xs font-semibold text-muted-foreground">Subtitle-focused results</span>
                    </Link>
                    <Link to={animePath(anime, latestAiredEpisode ? `/downloads?ep=${latestAiredEpisode}&type=dub` : '/downloads?type=dub')} className="rounded-xl border border-border bg-background/70 px-4 py-3 text-sm font-black text-foreground transition-colors hover:border-primary/45 hover:text-primary">
                      Dub quick link
                      <span className="mt-1 block text-xs font-semibold text-muted-foreground">Dual-audio and dub results</span>
                    </Link>
                  </div>
                </div>
              </section>
            ) : (
              <section className="rounded-2xl border border-border bg-secondary/25 p-4 md:p-5">
                <p className="text-[11px] font-black uppercase tracking-wider text-muted-foreground">Downloads unavailable</p>
                <h3 className="mt-1 text-xl font-black text-foreground">Source search opens after airing</h3>
                <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">
                  {anime.title} has not aired yet, so StreamNyaa does not show download source searches for this title. This prevents unrelated or similarly named source results from appearing before release.
                </p>
              </section>
            )}

            <div>
              <h3 className="text-lg font-bold mb-2">Synopsis</h3>
              <p className="text-muted-foreground leading-relaxed">
                {anime.synopsis || 'No synopsis available.'}
              </p>
            </div>

            <div>
              <h3 className="text-lg font-bold mb-2">Genres</h3>
              <div className="flex flex-wrap gap-2">
                {anime.genres?.map((g: any) => (
                  <Link
                    key={g.name}
                    to={`/search?genre=${g.name}`}
                    className="px-3 py-1 bg-secondary/50 hover:bg-secondary text-sm rounded-full text-foreground transition-colors"
                  >
                    {g.name}
                  </Link>
                ))}
              </div>
            </div>

            <section className="mt-7 pt-5 border-t border-[var(--glass-border)]">
              <h3 className="text-base font-bold mb-3">Quick info</h3>
              <div className="flex flex-wrap gap-2.5">
                {[
                  { label: 'Status', value: statusLabel },
                  { label: 'Episodes', value: anime.episodes ? `${anime.episodes} eps` : nextEpisodeNumber ? `${Math.max(nextEpisodeNumber - 1, 0)} aired` : 'TBA' },
                  { label: 'Format', value: anime.year ? `${anime.type || 'Anime'} - ${anime.year}` : anime.type || 'Anime' },
                  { label: 'MAL score', value: anime.score ? `${anime.score}/10` : 'N/A' },
                  { label: 'Popularity', value: malPopularityText },
                  { label: 'Studio', value: mainStudio || 'TBA' },
                  { label: 'Genres', value: genres.slice(0, 2).join(', ') || 'TBA' },
                ].map((item) => (
                  <div key={item.label} className="flex max-w-full items-center gap-2 rounded-full border border-[var(--glass-border)] bg-[var(--glass)] px-3 py-2">
                    <span className="text-[11px] font-black uppercase text-primary">{item.label}</span>
                    <span className="max-w-[180px] truncate text-sm font-semibold text-foreground">{item.value}</span>
                  </div>
                ))}
              </div>
              {(nextEpisodeNumber || genres.length > 2) && (
                <p className="mt-3 text-sm text-muted-foreground">
                  {nextEpisodeNumber ? `Next listed episode: ${nextEpisodeNumber}${nextAiringTime ? ` - ${nextAiringTime}` : ''}.` : ''}
                  {genres.length > 2 ? ` More genres: ${genres.slice(2, 5).join(', ')}.` : ''}
                </p>
              )}
            </section>

            <section className="mt-8 pt-6 border-t border-[var(--glass-border)] space-y-4">
              <div>
                <h3 className="text-lg font-bold mb-2">Episode and release information</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {anime.status === 'RELEASING'
                    ? `${anime.title} is currently airing. ${nextEpisodeNumber ? `Episode ${nextEpisodeNumber} is the next listed episode${nextAiringTime ? ` and is scheduled around ${nextAiringTime}` : ''}.` : 'New episode timing is updated when schedule data is available.'} The episode list below focuses on episodes that are already available or listed by public metadata.`
                    : anime.status === 'FINISHED'
                      ? `${anime.title} is listed as finished, so the episode list is useful for browsing the full release order, checking episode pages, and opening download searches.`
                      : `${anime.title} has release information listed as ${statusLabel}. Episode details may update as more official metadata becomes available.`}
                </p>
              </div>
              <div>
                <h3 className="text-lg font-bold mb-2">Download context</h3>
                <p className="text-muted-foreground leading-relaxed">
                  StreamNyaa organizes {anime.title} with episode navigation, related anime, recommendations, and download search tools. The downloads page can search source metadata by episode, batch, quality, subtitle, or dub preference, while this page keeps the anime details and episode order easy to scan.
                </p>
              </div>
            </section>

            <section className="mt-8 pt-6 border-t border-[var(--glass-border)]">
              <h3 className="text-lg font-bold mb-3">Explore {anime.title}</h3>
              <div className="flex flex-wrap gap-2">
                {downloadOptionsAvailable ? (
                  <Link to={animePath(anime, '/downloads')} className="rounded-full border border-primary/20 bg-primary/10 px-3 py-1.5 text-sm font-bold text-primary hover:bg-primary/20 transition-colors">Download sources</Link>
                ) : null}
                <Link to="/schedule" className="rounded-full border border-border bg-secondary/40 px-3 py-1.5 text-sm font-bold hover:border-primary/40 hover:text-primary transition-colors">Airing schedule</Link>
                <Link to="/anime/popular" className="rounded-full border border-border bg-secondary/40 px-3 py-1.5 text-sm font-bold hover:border-primary/40 hover:text-primary transition-colors">Popular anime</Link>
                {genres.slice(0, 3).map((genre: string) => (
                  <Link key={genre} to={`/anime/genre/${genre.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')}`} className="rounded-full border border-border bg-secondary/40 px-3 py-1.5 text-sm font-bold hover:border-primary/40 hover:text-primary transition-colors">
                    {genre} anime
                  </Link>
                ))}
              </div>
            </section>

            {!desktop ? (
              <RelatedBlogArticles
                title={`Articles related to ${anime.title}`}
                animeTitle={anime.title}
                malId={anime.mal_id}
                genres={genres}
                className="mt-8 pt-6 border-t border-[var(--glass-border)]"
              />
            ) : null}

            {anime.relations && anime.relations.length > 0 && (
              <div className="relative group/carousel">
                <h3 className="text-lg font-bold mb-4 mt-8 pt-6 border-t border-[var(--glass-border)]">Related Anime</h3>
                <button 
                  onClick={() => scroll(relationsScrollRef, 'left')}
                  className="absolute left-0 top-[60%] -translate-y-1/2 -ml-4 z-10 p-2 bg-background/80 backdrop-blur border border-[var(--glass-border)] rounded-full shadow-lg opacity-0 group-hover/carousel:opacity-100 transition-opacity disabled:opacity-0 hidden md:flex"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <div ref={relationsScrollRef} className="flex overflow-x-auto gap-4 pb-4 snap-x pr-4 scroll-smooth hide-scrollbar w-full">
                    {anime.relations.flatMap((r: any) => 
                      r.entry.map((entry: any) => (
                        <Link 
                          key={`${r.relation}-${entry.mal_id}`} 
                          to={entry.type === 'MANGA' ? mangaPath(entry) : animePath(entry)}
                          className="flex-none w-[140px] sm:w-[160px] md:w-[180px] group snap-start"
                        >
                          <div className="aspect-[2/3] rounded-xl overflow-hidden mb-3 relative bg-secondary border border-[var(--glass-border)]">
                            <img 
                              src={entry.images?.jpg?.large_image_url || entry.images?.jpg?.image_url} 
                              alt={entry.name}
                              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                              loading="lazy"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-3">
                               <span className="text-[11px] uppercase font-black text-primary tracking-wider">{r.relation.replace(/_/g, ' ')}</span>
                            </div>
                          </div>
                          <h4 className="text-sm font-semibold line-clamp-2 transition-colors group-hover:text-primary leading-tight">{entry.name}</h4>
                          <p className="text-xs text-muted-foreground mt-1.5 capitalize font-medium">{entry.type}</p>
                        </Link>
                      ))
                    )}
                </div>
                <button 
                  onClick={() => scroll(relationsScrollRef, 'right')}
                  className="absolute right-0 top-[60%] -translate-y-1/2 -mr-4 z-10 p-2 bg-background/80 backdrop-blur border border-[var(--glass-border)] rounded-full shadow-lg opacity-0 group-hover/carousel:opacity-100 transition-opacity disabled:opacity-0 hidden md:flex"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            )}

            {anime.recommendations && anime.recommendations.length > 0 && (
              <div className="relative group/carousel">
                <h3 className="text-lg font-bold mb-4 mt-8 pt-6 border-t border-[var(--glass-border)]">Recommendations</h3>
                <button 
                  onClick={() => scroll(recommendationsScrollRef, 'left')}
                  className="absolute left-0 top-[60%] -translate-y-1/2 -ml-4 z-10 p-2 bg-background/80 backdrop-blur border border-[var(--glass-border)] rounded-full shadow-lg opacity-0 group-hover/carousel:opacity-100 transition-opacity disabled:opacity-0 hidden md:flex"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <div ref={recommendationsScrollRef} className="flex overflow-x-auto gap-4 pb-4 snap-x pr-4 scroll-smooth hide-scrollbar w-full">
                    {anime.recommendations.map((entry: any) => (
                      <Link 
                        key={`rec-${entry.mal_id}`} 
                        to={entry.type === 'MANGA' ? mangaPath(entry) : animePath(entry)}
                        className="flex-none w-[140px] sm:w-[160px] md:w-[180px] group snap-start"
                      >
                        <div className="aspect-[2/3] rounded-xl overflow-hidden mb-3 relative bg-secondary border border-[var(--glass-border)]">
                          <img 
                            src={entry.images?.jpg?.large_image_url || entry.images?.jpg?.image_url} 
                            alt={entry.title}
                            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                            loading="lazy"
                          />
                        </div>
                        <h4 className="text-sm font-semibold line-clamp-2 transition-colors group-hover:text-primary leading-tight">{entry.title}</h4>
                      </Link>
                    ))}
                </div>
                <button 
                  onClick={() => scroll(recommendationsScrollRef, 'right')}
                  className="absolute right-0 top-[60%] -translate-y-1/2 -mr-4 z-10 p-2 bg-background/80 backdrop-blur border border-[var(--glass-border)] rounded-full shadow-lg opacity-0 group-hover/carousel:opacity-100 transition-opacity disabled:opacity-0 hidden md:flex"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            )}

            {/* Episodes List */}
            <div className="mt-8 pt-6 border-t border-[var(--glass-border)]">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4">
                <div className="flex items-center gap-3">
                  <h3 className="text-lg font-bold">Episodes</h3>
                  <span className="text-sm px-2 py-0.5 bg-secondary rounded-md font-medium text-foreground">{anime.episodes || '?'} Episodes</span>
                </div>
                
                {(() => {
                  const airedCount = anime?.nextAiringEpisode ? anime.nextAiringEpisode.episode - 1 : 
                    (anime?.status === 'RELEASING' || anime?.status === 'NOT_YET_RELEASED' ? (episodesData?.data?.length > 0 ? Math.max(...episodesData.data.map((e: any) => e.mal_id)) : 0) : (anime?.episodes || (episodesData?.data?.length > 0 ? Math.max(...episodesData.data.map((e: any) => e.mal_id)) : 12)));
                  const lastVisiblePage = Math.ceil(airedCount / 100) || 1;
                  
                  if (lastVisiblePage > 1) {
                    return (
                      <select 
                        className="bg-secondary text-[13px] font-semibold rounded-lg px-3 py-2 border border-border focus:outline-none focus:border-primary cursor-pointer text-foreground"
                        value={epPage}
                        onChange={(e) => setEpPage(parseInt(e.target.value))}
                      >
                        {Array.from({ length: lastVisiblePage }, (_, i) => (
                          <option key={i} value={i} className="bg-background">
                            Episodes {i * 100 + 1} - {i === lastVisiblePage - 1 ? airedCount : (i + 1) * 100}
                          </option>
                        ))}
                      </select>
                    );
                  }
                  return null;
                })()}
              </div>
              <div className="space-y-4 max-w-5xl">
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                  {(() => {
                    const episodes = episodesData?.data || [];
                    const airedCount = anime?.nextAiringEpisode ? anime.nextAiringEpisode.episode - 1 : 
                      (anime?.status === 'RELEASING' || anime?.status === 'NOT_YET_RELEASED' ? (episodes.length > 0 ? Math.max(...episodes.map((e: any) => e.mal_id)) : 0) : (anime?.episodes || (episodes.length > 0 ? Math.max(...episodes.map((e: any) => e.mal_id)) : 12)));
                    const maxEpCount = airedCount;

                    const displayEpisodes = Array.from({ length: 100 }, (_, i) => {
                      const epNum = epPage * 100 + i + 1;
                      if (epNum > maxEpCount) return null;
                      
                      const jikanEp = episodes.find((e: any) => e.mal_id === epNum);
                      if (jikanEp) return jikanEp;
                      
                      let epTitle = `Episode ${epNum}`;
                      return { mal_id: epNum, title: epTitle, image: '' };
                    }).filter(Boolean);
                    
                    return displayEpisodes.map((ep: any, index: number) => {
                      const epNum = ep.mal_id || epPage * 100 + index + 1;
                      return (
                        <div key={epNum} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-[var(--glass)] border border-[var(--glass-border)] rounded-xl gap-4">
                          <div className="flex items-center gap-4 min-w-0">
                            <span className="text-xl font-black text-muted-foreground w-8 shrink-0">{epNum}</span>
                            <div className="min-w-0 flex-1">
                              <h4 className="font-semibold text-base line-clamp-1">{ep.title || ep.title_romanji || ep.title_english || `Episode ${epNum}`}</h4>
                              {ep.aired && <p className="text-xs text-muted-foreground mt-1">{new Date(ep.aired).toLocaleDateString()}</p>}
                            </div>
                          </div>
                          
                          <div className="flex flex-wrap items-center gap-2 shrink-0">
                            <Link 
                              to={`${animePath(anime, '/downloads')}?ep=${epNum}&type=sub`}
                              className="flex items-center gap-1.5 px-3 py-1.5 bg-primary/10 hover:bg-primary/20 text-primary rounded-lg text-sm font-semibold transition-colors shrink-0"
                            >
                              <Download className="w-3.5 h-3.5" />
                              DL Sub
                            </Link>
                            <Link 
                              to={`${animePath(anime, '/downloads')}?ep=${epNum}&type=dub`}
                              className="flex items-center gap-1.5 px-3 py-1.5 bg-secondary hover:bg-secondary/80 text-foreground rounded-lg text-sm font-semibold transition-colors shrink-0"
                            >
                              <Download className="w-3.5 h-3.5" />
                              DL Dub
                            </Link>
                          </div>
                        </div>
                      );
                    });
                  })()}
                </div>
              </div>
            </div>

            <section className="mt-8 pt-6 border-t border-[var(--glass-border)]">
              <h3 className="text-lg font-bold mb-4">FAQ</h3>
              <div className="grid gap-4 md:grid-cols-3">
                {[
                  {
                    question: `What is ${anime.title} about?`,
                    answer: anime.synopsis || `${anime.title} is an anime page with metadata, episode information, related titles, and StreamNyaa discovery links.`,
                  },
                  {
                    question: `Is ${anime.title} currently airing?`,
                    answer: `${anime.title} is listed as ${statusLabel}.${anime.status === 'RELEASING' && nextEpisodeNumber ? ` The next listed episode is episode ${nextEpisodeNumber}${nextAiringTime ? ` around ${nextAiringTime}` : ''}.` : ''}`,
                  },
                  {
                    question: `Can I find ${anime.title} episode downloads?`,
                    answer: `Yes. Open the downloads page to search source metadata for ${anime.title}, including episode results, file sizes, seed counts, and sub or dub filters.`,
                  },
                ].map((item) => (
                  <div
                    key={item.question}
                    className={`rounded-xl p-4 ${
                      desktop
                        ? 'border border-white/8 bg-white/[0.045]'
                        : 'border border-[var(--glass-border)] bg-secondary/20'
                    }`}
                  >
                    <h4 className={`font-bold ${desktop ? 'text-white' : 'text-foreground'}`}>{item.question}</h4>
                    <p className={`mt-2 text-sm leading-relaxed ${desktop ? 'text-white/56' : 'text-muted-foreground'}`}>{item.answer}</p>
                  </div>
                ))}
              </div>
            </section>
            
          </div>
        </div>
      </div>
    </div>
  );
}
