export type DownloadState = 'queued' | 'downloading' | 'verifying' | 'paused' | 'failed' | 'cancelled' | 'completed';
export interface DesktopDownload { id: string; title: string; state: DownloadState; downloaded: number; total: number; error?: string }
export interface DesktopDownloadQueue { version: 1; limitBps: number; items: DesktopDownload[] }
function invoke<T>(command: string, args?: Record<string, unknown>): Promise<T> {
  const bridge = window.__TAURI__?.core?.invoke || window.__TAURI__?.invoke;
  if (!bridge) return Promise.reject(new Error('Downloads are available in the desktop app.'));
  return bridge<T>(command, args);
}
export const getDownloadQueue = () => invoke<DesktopDownloadQueue>('get_download_queue');
export const enqueueDownload = (title: string, magnet: string) => invoke<DesktopDownloadQueue>('enqueue_download', { title, magnet });
export const controlDownloads = (ids: string[], action: 'pause' | 'resume' | 'cancel' | 'retry') => invoke<DesktopDownloadQueue>('control_downloads', { ids, action });
export const setDownloadLimit = (limitBps: number) => invoke<DesktopDownloadQueue>('set_download_limit', { limitBps });
export const removeDownload = (id: string) => invoke<DesktopDownloadQueue>('remove_download', { id });
export const getOfflineFiles = (id: string) => invoke<string[]>('get_offline_files', { id });
export const playOfflineFile = (id: string, file: string) => invoke<void>('play_offline_file', { id, file });

export interface DesktopDownloadsChanged { version: 1 }
export async function listenDownloadsChanged(callback: () => void): Promise<() => void> {
  const listen = window.__TAURI__?.event?.listen;
  if (!listen) return () => {};
  return listen<DesktopDownloadsChanged>('streamnyaa-downloads-changed', event => {
    if (event.payload.version === 1) callback();
  });
}
