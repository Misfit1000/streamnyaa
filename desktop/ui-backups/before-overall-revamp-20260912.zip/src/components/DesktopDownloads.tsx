import { useEffect, useState } from 'react';
import { controlDownloads, listenDownloadsChanged, getDownloadQueue, getOfflineFiles, playOfflineFile, removeDownload, setDownloadLimit, type DesktopDownloadQueue } from '../lib/desktopDownloads';

export default function DesktopDownloads() {
  const [queue, setQueue] = useState<DesktopDownloadQueue>();
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [selected, setSelected] = useState<string[]>([]);
  const [files, setFiles] = useState<Record<string, string[]>>({});
  const [removing, setRemoving] = useState('');
  useEffect(() => {
    let disposed = false, pending = false;
    const refresh = async () => {
      if (pending || document.visibilityState === 'hidden') return;
      pending = true;
      try { const value = await getDownloadQueue(); if (!disposed) setQueue(value); }
      catch (issue) { if (!disposed) setError(String(issue instanceof Error ? issue.message : issue)); }
      finally { pending = false; }
    };
    void refresh(); const timer = window.setInterval(refresh, 3000);
    let unlisten: (() => void) | undefined;
    void listenDownloadsChanged(() => void refresh()).then(stop => { if (disposed) stop(); else unlisten = stop; }).catch(() => {});
    return () => { disposed = true; unlisten?.(); window.clearInterval(timer); };
  }, []);
  const act = async (operation: () => Promise<unknown>) => {
    if (busy) return;
    setBusy(true); setError('');
    try { await operation(); setQueue(await getDownloadQueue()); }
    catch (issue) { setError(String(issue instanceof Error ? issue.message : issue)); }
    finally { setBusy(false); }
  };
  return <section aria-label="Downloads and Offline Library" className="my-6 rounded-xl border border-white/10 bg-white/[0.025] p-5">
    <h2 className="text-xl font-semibold">Downloads &amp; Offline Library</h2>
    <p className="mt-2 text-sm text-white/60">Download releases from the source list. Downloads continue independently of playback, one at a time. After restarting the app, select Resume. Cancel retains partial files; Remove deletes them. Retry verifies retained files and repairs missing pieces.</p>
    <div className="mt-4 flex flex-wrap items-center gap-3">
      <label className="text-sm">Download speed <select aria-label="Download speed limit" disabled={busy} value={queue?.limitBps || 0} onChange={event => void act(() => setDownloadLimit(Number(event.target.value)))} className="ml-2 rounded bg-zinc-900 p-2">
        <option value={0}>Unlimited</option>{[1, 2, 5, 10, 20].map(n => <option key={n} value={n * 1_000_000}>{n} MB/s</option>)}
      </select></label>
      {(['pause', 'resume', 'cancel', 'retry'] as const).map(action => <button key={action} disabled={busy || !selected.length} className="sn-secondary-action px-3 py-2 disabled:opacity-40" onClick={() => void act(() => controlDownloads(selected, action))}>{action[0].toUpperCase() + action.slice(1)} selected</button>)}
    </div>
    {error && <p role="alert" className="mt-3 text-sm text-red-300">{error}</p>}
    {queue && !queue.items.length && <p className="mt-4 text-sm text-white/60">No downloads yet.</p>}
    {queue && queue.items.length > 0 && <button disabled={busy} className="sn-secondary-action mt-3 px-3 py-2" onClick={() => setSelected(selected.length === queue.items.length ? [] : queue.items.map(item => item.id))}>{selected.length === queue.items.length ? 'Clear selection' : 'Select all downloads'}</button>}
    <ul className="mt-4 space-y-3">{queue?.items.map(item => <li key={item.id} className="rounded-lg border border-white/10 p-3">
      <div className="flex flex-wrap items-center gap-3">
        <input type="checkbox" aria-label={`Select ${item.title}`} checked={selected.includes(item.id)} onChange={e => setSelected(ids => e.target.checked ? [...ids, item.id] : ids.filter(id => id !== item.id))} />
        <div className="min-w-0 flex-1"><p className="break-words text-sm font-semibold">{item.title}</p><p className="mt-1 text-sm text-white/60">{item.state}{item.total > 0 ? ` · ${Math.min(100, Math.floor(item.downloaded * 100 / item.total))}% verified` : ''}</p>{item.error && <p className="mt-1 text-sm text-red-300">{item.error}</p>}</div>
        {item.state === 'completed' && <button disabled={busy} className="sn-primary-action px-3 py-2" onClick={() => void act(async () => { const value = await getOfflineFiles(item.id); setFiles(previous => ({ ...previous, [item.id]: value })); })}>Offline videos</button>}
        {!['queued', 'downloading'].includes(item.state) && <button disabled={busy} className="sn-secondary-action px-3 py-2" onClick={() => setRemoving(item.id)}>Remove</button>}
      </div>
      {removing === item.id && <div role="alert" className="mt-3 flex flex-wrap items-center gap-3 text-sm"><span>Delete this release and its local files?</span><button disabled={busy} className="sn-primary-action px-3 py-2" onClick={() => void act(async () => { await removeDownload(item.id); setFiles(previous => { const next = { ...previous }; delete next[item.id]; return next; }); setRemoving(''); setSelected(ids => ids.filter(id => id !== item.id)); })}>Delete files</button><button onClick={() => setRemoving('')}>Keep files</button></div>}
      {files[item.id]?.length === 0 && <p role="status" className="mt-2 text-sm text-amber-200">No playable files were found. Select this release and Retry to verify and restore missing files.</p>}
      {files[item.id]?.map(file => <button key={file} disabled={busy} onClick={() => void act(() => playOfflineFile(item.id, file))} className="mt-2 block max-w-full break-words rounded bg-white/5 px-3 py-2 text-left text-sm">Play · {file}</button>)}
    </li>)}</ul>
  </section>;
}
