import { Bookmark, Heart } from 'lucide-react';
import { useStore } from '../store/useStore';

export default function DesktopCatalogActions({ anime }: { anime: any }) {
  const id = String(anime?.mal_id ?? anime?.id ?? anime?.title ?? '');
  const saved = useStore(state => state.isInMyList(id));
  const liked = useStore(state => state.isLiked(id));
  const title = anime.title || 'anime';
  return <div className="mt-2 flex gap-2">
    <button type="button" aria-label={`${saved ? 'Unsave' : 'Save'} ${title}`} aria-pressed={saved} className="sn-secondary-action min-h-10 flex-1 px-2 text-xs" onClick={() => { const store = useStore.getState(); if (saved) store.removeFromMyList(id); else store.addToMyList(anime); }}><Bookmark className={`h-3.5 w-3.5 ${saved ? 'fill-current' : ''}`} />{saved ? 'Saved' : 'Save'}</button>
    <button type="button" aria-label={`${liked ? 'Unfavorite' : 'Favorite'} ${title}`} aria-pressed={liked} className="sn-secondary-action min-h-10 px-3" onClick={() => useStore.getState().toggleLike(anime)}><Heart className={`h-3.5 w-3.5 ${liked ? 'fill-current text-primary' : ''}`} /></button>
  </div>;
}
